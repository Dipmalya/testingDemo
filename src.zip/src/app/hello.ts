export function helloWorld() {
    return "Hello World!";
}

export function helloWorldName(name: string) {
    return "Hello World!" + name;
}

export function compute(num: number) {
    if (num <= 0)
        return (num - 2 * num);
}

export class AuthService{
    isAuthenticated():boolean{
        return !!localStorage.getItem('token');
    }
}