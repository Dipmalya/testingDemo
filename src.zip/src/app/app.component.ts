import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h1>Hello {{name}} </h1>
  <br/>
   <button (click)="increment()" class="increment">Increment</button><br/><br/><br/>
   <button (click)="decrement()" class="decrement">Decrement</button><br/><br/>
   <h2>{{value}}</h2> <hr/>`
})
export class AppComponent { 
  name = 'DS'; 
  items:Array<String>;
  value:number=4;
  constructor(){
    this.items=["Dip","Bizz","AriK"];
  }

  increment(){
    if(this.value<15){
      this.value++;
    }
  }
}
