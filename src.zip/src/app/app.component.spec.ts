/*import { helloWorld, helloWorldName, compute, AuthService } from './hello';

describe(
    "This is first suite",()=>{
        let service:AuthService;
        beforeEach(()=>{
            service = new AuthService();
        });

        afterEach(()=>{
            service=null;
            localStorage.clear();
        });

        it("This is 1st spec",()=>{
            expect(helloWorld()).toEqual("Hello World!");
        });

        it("This is 2nd spec",()=>{
            const name="Dip";
            expect(helloWorldName(name)).toContain(name);
        });

        it("This is 3rd spec",()=>{
            const num=-5;
            expect(compute(num)).toBe(5);
        });

        it("This is beforeEach test",()=>{
            localStorage.setItem('token','Dip');
            expect(service.isAuthenticated()).toBeTruthy();
        });

        it("This is afterEach test",()=>{
            expect(service.isAuthenticated()).toBeFalsy();
        })
    }
)*/

import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { DebugElement } from '@angular/core'
import { AppComponent } from './app.component';
import { By } from '@angular/platform-browser';

describe(
    "Testing App Component", () => {

        let app: AppComponent;
        let comp: AppComponent;
        let debugElement: DebugElement;
        let componentInstance: AppComponent;
        let fixture: ComponentFixture<AppComponent>;
        let compElement;

        /*******************************************/

        beforeEach(async () => {
            TestBed.configureTestingModule(
                {
                    declarations: [AppComponent]
                }
            ).compileComponents();
        });

        beforeEach(() => {
            fixture = TestBed.createComponent(AppComponent);
            debugElement = fixture.debugElement;
            app = fixture.debugElement.componentInstance;
            comp = fixture.debugElement.componentInstance;
        })


        it("App Component Test Bed Testing.. should create appcomponent", async () => {
            expect(app).toBeTruthy();
        });

        /*it("Should define the name ", () => {
            expect(app.name).toEqual("Welcome");
        });*/

        it("Check for entries in the array", () => {
            expect(app.items.length).toBe(3);
        });

        it("Check whether name is rendered in h1 tag", async(async () => {
            const fixture = TestBed.createComponent(AppComponent);
            fixture.detectChanges();
            const compElement=fixture.debugElement.nativeElement;
            expect(compElement.querySelector("h1").textContent).toContain("Hello "+comp.name);
        }));

        it("Increment",async(async()=>{
            debugElement.query(By.css("button.increment")).triggerEventHandler("click",null);

            fixture.detectChanges();

            const value = debugElement.query(By.css("h2")).nativeElement.innerText;
            expect(value).toEqual("5");
            
        }))
    }
);